package fr.mines.religion.infrastructure.repository;

import fr.mines.religion.domain.model.Implication;
import fr.mines.religion.domain.model.Person;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ImplicationRepositoryAdapterTest {

    @Test
    void insert() {

    }
}