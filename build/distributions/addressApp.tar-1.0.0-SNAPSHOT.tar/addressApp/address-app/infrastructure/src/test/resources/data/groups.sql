insert into groups(id, name, description, type, region , position , beliefs) VALUES (uuid('77643c27-d221-4f34-b11c-3732405cd83a'), 'name', 'description', 'religion', 'region' , 'position' , 'beliefs');

