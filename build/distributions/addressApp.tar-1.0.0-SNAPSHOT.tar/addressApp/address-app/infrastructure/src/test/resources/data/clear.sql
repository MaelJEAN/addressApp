truncate table targetaddress;
truncate table address;
truncate table town;
truncate table target;