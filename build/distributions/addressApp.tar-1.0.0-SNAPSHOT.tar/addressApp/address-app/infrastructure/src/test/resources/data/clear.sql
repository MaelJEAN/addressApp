truncate table targetaddress;
truncate table address;
truncate table town;
truncate table target;

truncate table groups;
truncate table person;
truncate table implication;