package org.mines.address.domain.model;

import java.util.UUID;

public record Target(UUID uuid, String firstName, String lastName) {
}
