package org.mines.examples.patterns.model;

@FunctionalInterface
public interface Color {

    String getRgb();

}
